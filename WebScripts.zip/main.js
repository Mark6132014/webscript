// ===== main.js =====

// Normalize IP/host into a full URL
function normalizeUrl(ip, path, query, hash) {
    const hasProtocol = /^https?:\/\//i.test(ip);
    const base = hasProtocol ? ip : "http://" + ip;
    return base + path + query + hash;
}

// Replace entire page with fullscreen iframe
function doDnsOverride(ip, path, query, hash, title, icon) {
    const overrideUrl = normalizeUrl(ip, path, query, hash);
    console.log("[WebScripts] DNS override to:", overrideUrl);

    document.open();
    document.write(`
        <html>
        <head>
            <meta charset="utf-8">
            <title>${title || ""}</title>
            ${icon ? `<link rel="icon" href="${icon}">` : ""}
            <style>
                html, body {
                    margin: 0;
                    padding: 0;
                    height: 100%;
                    overflow: hidden;
                }
                iframe {
                    width: 100%;
                    height: 100%;
                    border: none;
                }
            </style>
        </head>
        <body>
            <iframe src="${overrideUrl}"></iframe>
        </body>
        </html>
    `);
    document.close();
}

// Inject raw JS code into <body> as <script>
function injectInlineScript(code) {
    try {
        console.log("[WebScripts] Injecting inline rule script...");
        const s = document.createElement("script");
        s.textContent = code;

        if (document.body) {
            document.body.appendChild(s);
        } else {
            document.documentElement.appendChild(s);
        }
    } catch (e) {
        console.error("WebScripts: failed to inject inline script:", e);
    }
}

// MAIN EXECUTION
chrome.storage.local.get(
    [
        "webscripts_dnsConfig",
        "webscripts_dnsTitle",
        "webscripts_dnsIcon",
        "webscripts_ruleCode",
        "blocklist"
    ],
    (data) => {

        const dnsConfig = data.webscripts_dnsConfig || {};
        const dnsTitle  = data.webscripts_dnsTitle  || {};
        const dnsIcon   = data.webscripts_dnsIcon   || {};
        const ruleCode  = data.webscripts_ruleCode  || {};
        const blocklist = data.blocklist            || [];

        const hostname  = window.location.hostname;
        console.log("[WebScripts] Current hostname:", hostname);
        console.log("[WebScripts] Blocklist:", blocklist);

        // 0) BLOCKLIST CHECK
        if (blocklist.includes(hostname)) {
            console.log("[WebScripts] Hostname is blocklisted. Skipping DNS override and rules.");
            return;
        }

        console.log("[WebScripts] Available rule hostnames:", Object.keys(ruleCode));
        console.log("[WebScripts] Available DNS hostnames:", Object.keys(dnsConfig));

        // 1) RULES: always try to inject if present
        if (ruleCode[hostname]) {
            console.log("[WebScripts] Rule found for hostname. Injecting...");
            injectInlineScript(ruleCode[hostname]);
        } else {
            console.log("[WebScripts] No rule code for this hostname.");
        }

        // 2) DNS OVERRIDE: if configured, override
        if (dnsConfig[hostname] && dnsConfig[hostname].ip) {
            try {
                const ip     = dnsConfig[hostname].ip;
                const loc    = window.location;
                const path   = loc.pathname || "/";
                const query  = loc.search || "";
                const hash   = loc.hash || "";

                const title = dnsTitle[hostname] || "";
                const icon  = dnsIcon[hostname]  || "";

                doDnsOverride(ip, path, query, hash, title, icon);
            } catch (e) {
                console.error("WebScripts DNS override failed:", e);
            }
        } else {
            console.log("[WebScripts] No DNS override for this hostname.");
        }
    }
);
