(async () => {
    // Load settings
    const { webscriptUrl, blocklist } = await chrome.storage.local.get([
        "webscriptUrl",
        "blocklist"
    ]);

    if (!webscriptUrl) return;

    // Auto-append JSON filename if needed
    let manifestUrl = webscriptUrl;
    if (!manifestUrl.toLowerCase().endsWith(".json")) {
        manifestUrl = manifestUrl.replace(/\/$/, "") + "/webscript.json";
    }

    // Fetch manifest
    let manifest;
    try {
        const res = await fetch(manifestUrl, { cache: "no-store" });
        manifest = await res.json();
    } catch (err) {
        console.error("WebScripts: failed to fetch manifest", err);
        return;
    }

    if (!manifest || manifest.type !== "webscript") return;

    const hostname = location.hostname;

    // BLOCKLIST PROTECTION
    if (blocklist && blocklist.includes(hostname)) {
        console.log("WebScripts: domain blocked:", hostname);
        return;
    }

    // ------------------------------------------------------------
    // 1. CSP-SAFE SCRIPT INJECTION (BLOB METHOD)
    // ------------------------------------------------------------
    async function injectScriptCSPsafe(url) {
        try {
            const code = await (await fetch(url)).text();

            const blob = new Blob([code], { type: "text/javascript" });
            const blobUrl = URL.createObjectURL(blob);

            const s = document.createElement("script");
            s.src = blobUrl;
            s.type = "text/javascript";
            s.async = false;

            document.documentElement.appendChild(s);
        } catch (err) {
            console.error("WebScripts: failed to inject script", err);
        }
    }

    // ------------------------------------------------------------
    // 2. RULES SECTION (CSP-SAFE)
    // ------------------------------------------------------------
    if (manifest.rules && manifest.rules[hostname]) {
        const scriptUrl = manifest.rules[hostname].script;

        injectScriptCSPsafe(scriptUrl);
        return;
    }

    // ------------------------------------------------------------
    // 3. DNS OVERRIDE SECTION (FIXED PROTOCOL + CLEAN REWRITE)
    // ------------------------------------------------------------
    if (manifest.dns && manifest.dns[hostname]) {
        let target = manifest.dns[hostname].ip;

        // If no protocol, default to http://
        if (!/^https?:\/\//i.test(target)) {
            target = "http://" + target;
        }

        try {
            const response = await fetch(target, { mode: "cors" });
            const html = await response.text();

            // Rewrite the page early and cleanly
            document.open();
            document.write(
                `<base href="${target}/">` +
                html
            );
            document.close();

        } catch (err) {
            console.error("WebScripts: DNS override failed", err);
        }

        return;
    }

    // If neither rules nor dns matched, do nothing
})();
