const urlInput = document.getElementById("jsonUrl");
const blocklistInput = document.getElementById("blocklist");
const applyBtn = document.getElementById("applyBtn");
const testBtn = document.getElementById("testBtn");
const warning = document.getElementById("warning");
const testResult = document.getElementById("testResult");
const consoleBox = document.getElementById("consoleBox");

// Log to console box
function log(msg) {
    consoleBox.textContent += msg + "\n";
    consoleBox.scrollTop = consoleBox.scrollHeight;
}

// Proper logToBox function (as requested)
function logToBox(message, color = "#0f0") {
    const box = document.getElementById("consoleBox");
    if (!box) {
        console.error("consoleBox element not found in popup.html");
        return;
    }

    const line = document.createElement("div");
    line.style.color = color;
    line.textContent = message;

    box.appendChild(line);
    box.scrollTop = box.scrollHeight; // auto-scroll
}

// --- HTTP WARNING ---------------------------------------------------------
urlInput.addEventListener("input", () => {
    const value = urlInput.value.trim().toLowerCase();

    if (value.startsWith("http://")) {
        warning.style.color = "orange";
        warning.textContent =
            "It is recommended to use HTTPS. HTTP is outdated and not secure. If you trust this WebScript address and it only works on HTTP, you may continue.";
    } else {
        warning.textContent = "";
    }
});

// --- APPLY BUTTON ---------------------------------------------------------
applyBtn.addEventListener("click", async () => {
    const jsonUrl = urlInput.value.trim();
    const blocklistRaw = blocklistInput.value.trim();

    const blocklist = blocklistRaw
        .split("\n")
        .map(x => x.trim())
        .filter(x => x.length > 0);

    chrome.storage.local.set({
        webscriptUrl: jsonUrl,
        blocklist: blocklist
    });

    if (!jsonUrl) {
        logToBox("No WebScript URL set.", "red");
        return;
    }

    let manifestUrl = jsonUrl;
    if (!manifestUrl.endsWith(".json")) {
        manifestUrl = manifestUrl.replace(/\/$/, "") + "/webscript.json";
    }

    try {
        const res = await fetch(manifestUrl, { cache: "no-store" });
        if (!res.ok) throw new Error("Manifest HTTP " + res.status);
        const manifest = await res.json();

        const rules = manifest.rules || {};
        const dns   = manifest.dns   || {};

        // 1) Build rule code map: hostname -> JS
        const ruleCodeMap = {};
        for (const hostname of Object.keys(rules)) {
            const rule = rules[hostname];
            if (!rule || !rule.script) continue;

            const scriptUrl = rule.script;
            try {
                logToBox("Loading script for " + hostname + " from " + scriptUrl, "#0ff");
                const jsText = await fetch(scriptUrl, { cache: "no-store" }).then(r => r.text());
                ruleCodeMap[hostname] = jsText;
                logToBox("Loaded script for " + hostname, "lime");
            } catch (e) {
                logToBox("Failed to load script for " + hostname + ": " + e.message, "red");
            }
        }

        // 2) DNS title / icon
        const dnsTitleMap = {};
        const dnsIconMap  = {};
        for (const hostname of Object.keys(dns)) {
            const entry = dns[hostname] || {};
            dnsTitleMap[hostname] = entry.title || "";
            dnsIconMap[hostname]  = entry.icon  || "";
        }

        chrome.storage.local.set(
            {
                webscripts_ruleCode: ruleCodeMap,
                webscripts_dnsConfig: dns,
                webscripts_dnsTitle: dnsTitleMap,
                webscripts_dnsIcon: dnsIconMap
            },
            () => {
                logToBox("Saved rule JS, DNS config, titles, and icons.", "lime");
                alert("Settings applied!");
            }
        );

    } catch (e) {
        logToBox("Error fetching manifest: " + e.message, "red");
    }
});


// --- LOAD SAVED SETTINGS --------------------------------------------------
chrome.storage.local.get(["webscriptUrl", "blocklist"], (data) => {
    if (data.webscriptUrl) {
        urlInput.value = data.webscriptUrl;
    }
    if (data.blocklist) {
        blocklistInput.value = data.blocklist.join("\n");
    }
});

// --- TEST BUTTON ----------------------------------------------------------
testBtn.addEventListener("click", async () => {
    const base = urlInput.value.trim();
    if (!base) return;

    testResult.style.color = "gray";
    testResult.textContent = "Testing...";

    // Clear console box
    if (consoleBox) consoleBox.innerHTML = "";

    // --- PROTOCOL WARNING ---
    if (base.toLowerCase().startsWith("http://")) {
        logToBox("It is using HTTP. Not a secure connection! Change the site immediately if you dont trust it.", "red");
        testResult.style.color = "red";
        testResult.textContent = "⚠ It is using HTTP. Not a secure connection!";
        // continue anyway
    }

    const testUrl = base.replace(/\/$/, "") + "/webscript.json";

    try {
        const res = await fetch(testUrl, { cache: "no-store" });

        if (!res.ok) throw new Error("Not found");

        try {
            await res.text();
        } catch {
            logToBox("This site has a CORS problem", "red");
            testResult.style.color = "red";
            testResult.textContent = "✗ This site has a CORS problem";
            applyBtn.disabled = true;
            return;
        }

        testResult.style.color = "green";
        testResult.textContent = "✓ WebScript manifest found!";
        applyBtn.disabled = false;
        logToBox("Manifest found and readable!", "lime");

    } catch {
        testResult.style.color = "red";
        testResult.textContent = "✗ Could not find " + testUrl + ". Check the address.";
        applyBtn.disabled = true;
        logToBox("Manifest missing or unreachable.", "red");
    }
});
