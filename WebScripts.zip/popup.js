const urlInput = document.getElementById("jsonUrl");
const blocklistInput = document.getElementById("blocklist");
const applyBtn = document.getElementById("applyBtn");
const testBtn = document.getElementById("testBtn");
const warning = document.getElementById("warning");
const testResult = document.getElementById("testResult");
const consoleBox = document.getElementById("consoleBox");

// Log to console box
function log(msg) {
    consoleBox.textContent += msg + "\n";
    consoleBox.scrollTop = consoleBox.scrollHeight;
}

// --- HTTP WARNING ---------------------------------------------------------
urlInput.addEventListener("input", () => {
    const value = urlInput.value.trim().toLowerCase();

    if (value.startsWith("http://")) {
        warning.style.color = "orange";
        warning.textContent =
            "It is recommended to use HTTPS. HTTP is outdated and not secure. If you trust this WebScript address and it only works on HTTP, you may continue.";
    } else {
        warning.textContent = "";
    }
});

// --- APPLY BUTTON ---------------------------------------------------------
applyBtn.addEventListener("click", () => {
    const jsonUrl = urlInput.value.trim();
    const blocklistRaw = blocklistInput.value.trim();

    const blocklist = blocklistRaw
        .split("\n")
        .map(x => x.trim())
        .filter(x => x.length > 0);

    chrome.storage.local.set({
        webscriptUrl: jsonUrl,
        blocklist: blocklist
    }, () => {
        log("Settings applied.");
        alert("Settings applied!");
    });
});

// --- LOAD SAVED SETTINGS --------------------------------------------------
chrome.storage.local.get(["webscriptUrl", "blocklist"], (data) => {
    if (data.webscriptUrl) {
        urlInput.value = data.webscriptUrl;
    }
    if (data.blocklist) {
        blocklistInput.value = data.blocklist.join("\n");
    }
});

// --- TEST BUTTON ----------------------------------------------------------
function logToBox(message, color = "#0f0") {
    const box = document.getElementById("consoleBox");
    if (!box) {
        console.error("consoleBox element not found in popup.html");
        return;
    }

    const line = document.createElement("div");
    line.style.color = color;
    line.textContent = message;

    box.appendChild(line);
    box.scrollTop = box.scrollHeight; // auto-scroll
}

testBtn.addEventListener("click", async () => {
    const base = urlInput.value.trim();
    if (!base) return;

    testResult.style.color = "gray";
    testResult.textContent = "Testing...";

    // Clear console box
    document.getElementById("consoleBox").innerHTML = "";

    // --- PROTOCOL WARNING ---
    if (base.toLowerCase().startsWith("http://")) {
        logToBox("It is using HTTP. Not a secure connection! Change the site immediately if you dont trust it.", "red");
        testResult.style.color = "red";
        testResult.textContent = "⚠ It is using HTTP. Not a secure connection!";
        // continue anyway
    }

    const testUrl = base.replace(/\/$/, "") + "/webscript.json";

    try {
        const res = await fetch(testUrl, { cache: "no-store" });

        if (!res.ok) throw new Error("Not found");

        try {
            await res.text();
        } catch {
            logToBox("This site has a CORS problem", "red");
            testResult.style.color = "red";
            testResult.textContent = "✗ This site has a CORS problem";
            applyBtn.disabled = true;
            return;
        }

        testResult.style.color = "green";
        testResult.textContent = "✓ WebScript manifest found!";
        applyBtn.disabled = false;
        logToBox("Manifest found and readable!", "lime");

    } catch {
        testResult.style.color = "red";
        testResult.textContent = "✗ Could not find " + testUrl + ". Check the address.";
        applyBtn.disabled = true;
        logToBox("Manifest missing or unreachable.", "red");
    }
});
