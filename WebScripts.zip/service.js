// Fetch the remote WebScript JSON manifest
async function fetchManifest(url) {
    try {
        const res = await fetch(url, { cache: "no-store" });
        if (!res.ok) throw new Error("Failed to fetch manifest");
        return await res.json();
    } catch (err) {
        console.error("WebScripts: manifest fetch error:", err);
        return null;
    }
}

function getDomain(url) {
    try {
        return new URL(url).hostname;
    } catch {
        return "";
    }
}

function matchRule(domain, rules) {
    return rules[domain] || null;
}

// Ensure the API exists to avoid runtime crash
if (chrome.webNavigation && chrome.webNavigation.onCommitted) {
    chrome.webNavigation.onCommitted.addListener(async (details) => {
        if (details.frameId !== 0) return; // Only main frame

        const domain = getDomain(details.url);

        const { webscriptUrl, blocklist } = await chrome.storage.local.get([
            "webscriptUrl",
            "blocklist"
        ]);

        if (!webscriptUrl) return;

        if (blocklist && blocklist.includes(domain)) {
            console.log("WebScripts: blocked domain", domain);
            return;
        }

        const manifest = await fetchManifest(webscriptUrl);
        if (!manifest || manifest.type !== "webscript") return;

        const rule = matchRule(domain, manifest.rules || {});
        if (!rule || !rule.script) return;

        chrome.tabs.sendMessage(details.tabId, {
            type: "webscript-run",
            scriptUrl: rule.script
        });
    });
} else {
    console.error("WebScripts: chrome.webNavigation API is not available");
}
