// ===== service.js =====
chrome.runtime.onInstalled.addListener(() => {
    console.log("WebScripts service worker active.");
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === "ping") {
        sendResponse({ status: "ok" });
    }
});
